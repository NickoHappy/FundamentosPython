print("****************")
print("* Número Mayor *")
print("****************")
print(" \n ")


numero_uno = int(input(" Porfavor digite el primer número: "))
numero_dos = int(input(" Porfavor digite el segundo número: "))         
numero_tres = int(input(" Porfavor digite el tercer número: "))

if numero_uno > numero_dos and numero_uno > numero_tres:
                  print(" El numero mayor es: ", numero_uno)
else:
    if numero_dos > numero_tres:
        print(" El numero mayor es: ", numero_dos)
    else:
         print(" El numero mayor es: ", numero_tres)
        
                  




 

        
