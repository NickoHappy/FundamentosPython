print("*********************************")
print("* Sistema de Control Vacacional *")
print("*********************************")
print(" \n")

nombre_empleado = input (" Porfavor, digita el nombre del empleado: ")

clave_departamento = int(input (" Porfavor digita la clave: ") )

años_empleado = float (input ("Porfavor digita los años trabajados: "))

if clave_departamento == 1:
    if años_empleado == 1 and años_empleado < 2:
        print("El empleado ", nombre_empleado, "* tiene derecho a 6 días de vacaciones *")
    elif años_empleado >= 2 and años_empleado <= 6:
            print("El empleado ", nombre_empleado, "* tiene derecho a 14 días de vacaciones *")
    elif años_empleado >= 7:
                print("El empleado ", nombre_empleado, "* tiene derecho a 20 días de vacaciones *")
    else:
                print("El empleado ", nombre_empleado, "* No tiene derecho a vacaciones *")
                
            

elif clave_departamento == 2:
    if años_empleado == 1 and años_empleado < 2:
        print("El empleado ", nombre_empleado, "* tiene derecho a 7 días de vacaciones *")
    elif años_empleado >= 2 and años_empleado <= 6:
            print("El empleado ", nombre_empleado, "* tiene derecho a 15 días de vacaciones *")
    elif años_empleado >= 7:
                print("El empleado ", nombre_empleado, "* tiene derecho a 22 días de vacaciones *")
    else:
                print("El empleado ", nombre_empleado, "* No tiene derecho a vacaciones *")

elif clave_departamento == 3:
    if años_empleado == 1 and años_empleado < 2:
        print("El empleado ", nombre_empleado, "* tiene derecho a 10 días de vacaciones *")
    elif años_empleado >= 2 and años_empleado <= 6:
            print("El empleado ", nombre_empleado, "* tiene derecho a 20 días de vacaciones *")
    elif años_empleado >= 7:
                print("El empleado ", nombre_empleado, "* tiene derecho a 30 días de vacaciones *")
    else:
                print("El empleado ", nombre_empleado, "* No tiene derecho a vacaciones *")

else:
        print(" Clave no exitente")

