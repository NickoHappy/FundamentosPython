print("************************")
print("* ¿Número Par o impar? *")
print("************************")
print(" \n")



numero_entero = int(input(" Porfavor digite un número entero: "))

if numero_entero % 2 == 0:
    print("El número ",numero_entero, "es par")
    
elif numero_entero % 2 == 1:
    print("El número ",numero_entero, "es impar")
